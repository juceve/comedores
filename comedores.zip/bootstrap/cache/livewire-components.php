<?php return array (
  'controlclientes' => 'App\\Http\\Livewire\\Controlclientes',
  'entregas.listado' => 'App\\Http\\Livewire\\Entregas\\Listado',
);