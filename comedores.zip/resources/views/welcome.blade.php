@extends('layouts.web')
@section('content')
<div class="container text-center py-5">    
    @livewire('controlclientes')
</div>
@endsection
