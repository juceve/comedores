<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Clientes</title>
    <link href="<?php echo e(public_path('invoice/bootstrap.min.css')); ?>" rel="stylesheet" id="bootstrap-css">
    <script src="<?php echo e(public_path('invoice/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(public_path('invoice/jquery-1.11.1.min.js')); ?>"></script>
    <style>
        .invoice-title h2,
        .invoice-title h3 {
            display: inline-block;
        }

        .table>tbody>tr>.no-line {
            border-top: none;
        }

        .table>thead>tr>.no-line {
            border-bottom: none;
        }

        .table>tbody>tr>.thick-line {
            border-top: 2px solid;
        }
    </style>
</head>

<body>
<div class="table-responsive">
    <table class="table table-striped table-hover dataTable">
        <thead class="thead">
            <tr style="background-color: #d7d7d7">
                <th>No</th>                
                <th>Nombre</th>
                <th>Cargo</th>
                <th>Empresa</th>
                <th>Cedula</th>
                <th>Estado</th>

            </tr>
        </thead>
        <tbody>
            <?php
                $i = 0;
            ?>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$i); ?></td>                    
                    <td><?php echo e($cliente->nombre); ?></td>
                    <td><?php echo e($cliente->cargo); ?></td>
                    <td><?php echo e($cliente->empresa); ?></td>
                    <td><?php echo e($cliente->cedula); ?></td>
                    <td><?php echo e($cliente->estado); ?></td>                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

</body>

</html><?php /**PATH C:\xampp\htdocs\comedores\resources\views/cliente/reportes/clientes.blade.php ENDPATH**/ ?>