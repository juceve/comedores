<?php $__env->startSection('content'); ?>
<div class="container text-center py-5">    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('controlclientes')->html();
} elseif ($_instance->childHasBeenRendered('D3OCdRc')) {
    $componentId = $_instance->getRenderedChildComponentId('D3OCdRc');
    $componentTag = $_instance->getRenderedChildComponentTagName('D3OCdRc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('D3OCdRc');
} else {
    $response = \Livewire\Livewire::mount('controlclientes');
    $html = $response->html();
    $_instance->logRenderedChild('D3OCdRc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\comedores\resources\views/welcome.blade.php ENDPATH**/ ?>