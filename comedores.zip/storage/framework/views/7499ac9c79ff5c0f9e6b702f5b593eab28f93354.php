<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('fecha')); ?>

            <?php echo e(Form::text('fecha', $entrega->fecha, ['class' => 'form-control' . ($errors->has('fecha') ? ' is-invalid' : ''), 'placeholder' => 'Fecha'])); ?>

            <?php echo $errors->first('fecha', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cliente_id')); ?>

            <?php echo e(Form::text('cliente_id', $entrega->cliente_id, ['class' => 'form-control' . ($errors->has('cliente_id') ? ' is-invalid' : ''), 'placeholder' => 'Cliente Id'])); ?>

            <?php echo $errors->first('cliente_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('franja_id')); ?>

            <?php echo e(Form::text('franja_id', $entrega->franja_id, ['class' => 'form-control' . ($errors->has('franja_id') ? ' is-invalid' : ''), 'placeholder' => 'Franja Id'])); ?>

            <?php echo $errors->first('franja_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\comedores\resources\views/entrega/form.blade.php ENDPATH**/ ?>