<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Listado de Entregas</title>
    <link href="<?php echo e(public_path('invoice/bootstrap.min.css')); ?>" rel="stylesheet" id="bootstrap-css">
    <script src="<?php echo e(public_path('invoice/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(public_path('invoice/jquery-1.11.1.min.js')); ?>"></script>
    <style>
        .invoice-title h2,
        .invoice-title h3 {
            display: inline-block;
        }

        .table>tbody>tr>.no-line {
            border-top: none;
        }

        .table>thead>tr>.no-line {
            border-bottom: none;
        }

        .table>tbody>tr>.thick-line {
            border-top: 2px solid;
        }
    </style>
</head>

<body>
    <div class="content text-center mb-3">
        <h2>LISTADO DE ENTREGAS</h2>
        <small>Del <?php echo e($fechai); ?> al <?php echo e($fechaf); ?> </small><br>
    </div>
    <hr>
    <table class="table table-striped table-bordered">
        <thead style="background-color: #d1d1d1;">
            <tr>
                <th>Nro</th>

                <th>FECHA - HORA</th>
                <th>CLIENTE</th>
                <th>PRODUCTO</th>

            </tr>
        </thead>
        <tbody>
            <?php if(!is_null($entregas)): ?>
            <?php
                $i=0;
            ?>
            <?php $__currentLoopData = $entregas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrega): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>

                <td><?php echo e($entrega->created_at); ?></td>
                <td><?php echo e($entrega->cliente); ?></td>
                <td><?php echo e($entrega->franja); ?></td>


            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </tbody>
    </table>
</body>

</html><?php /**PATH C:\xampp\htdocs\comedores\resources\views/entrega/reportes/listado.blade.php ENDPATH**/ ?>